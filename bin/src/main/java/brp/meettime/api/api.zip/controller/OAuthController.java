package brp.meettime.api.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import brp.meettime.api.service.OAuthService;

@RestController
@RequestMapping("/oauth")
public class OAuthController {

    private final OAuthService oAuthService;

    public OAuthController(OAuthService oAuthService) {
        this.oAuthService = oAuthService;
    }
    
    @GetMapping("/authorize")
    public String getAuthorizationUrl() {
        return oAuthService.generateAuthorizationUrl();
    }
    
    @GetMapping("/callback")
    public ResponseEntity<String> handleOAuthCallback(@RequestParam(value = "code", required = false) String code) {
        System.out.println("Código recebido: " + code);

        if (code == null || code.isEmpty()) {
            return ResponseEntity.badRequest().body("Erro: Código de autorização não encontrado.");
        }

        String tokenResponse = oAuthService.exchangeCodeForAccessToken(code);
        return ResponseEntity.ok("Tokens armazenados com sucesso: " + tokenResponse);
    }
}



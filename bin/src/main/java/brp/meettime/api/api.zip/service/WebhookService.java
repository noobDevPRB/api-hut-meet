package brp.meettime.api.service;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import brp.meettime.api.model.WebhookEventDTO;

@Service
public class WebhookService {

	   private final ObjectMapper objectMapper = new ObjectMapper();

	    public void processContactCreation(WebhookEventDTO event) {
	        try {
	            String jsonEvent = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(event);
	            System.out.println("Evento processado: " + jsonEvent);
	        } catch (JsonProcessingException e) {
	            System.err.println("Erro ao converter evento para JSON: " + e.getMessage());
	        }

	    }
}
